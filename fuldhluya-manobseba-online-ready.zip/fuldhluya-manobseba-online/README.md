# ফুলঢলুয়া মানবসেবা সংগঠন — Online version

এই সংস্করণটি Supabase-এর সাথে যুক্ত। Admin Auth user এবং `public.admins` row আগে তৈরি করা থাকলে Admin ইমেইল/পাসওয়ার্ড দিয়ে লগইন করতে পারবেন।

## কী করা হয়েছে
- Supabase Project URL + Publishable key সংযুক্ত
- Public visitor-এর জন্য online `site_data` read
- Admin Auth login
- Admin-এর member/activity/notice/donation/expense/committee/payment/org data online save
- Admin member edit/delete এবং অন্যান্য record delete
- Supabase Realtime subscription: `site_data` update হলে open visitors-এর data refresh হবে

## নিরাপত্তা
- Browser-এ শুধু Publishable key রাখা হয়েছে।
- Secret/service_role key রাখা হয়নি।
- Database-এর RLS policy ব্যবহার করা হয়েছে।

## গুরুত্বপূর্ণ
Supabase SQL setup এবং Admin Auth user/`public.admins` row আগে তৈরি করা থাকতে হবে।

GitHub Pages-এ প্রকাশ করলে `index.html`-কে root হিসেবে রাখুন।

const { createClient } = window.supabase;
const SUPABASE_URL = window.FMS_SUPABASE_URL || "";
const SUPABASE_KEY = window.FMS_SUPABASE_PUBLISHABLE_KEY || "";
const sb = (SUPABASE_URL && SUPABASE_KEY) ? createClient(SUPABASE_URL, SUPABASE_KEY) : null;

const bn=n=>new Intl.NumberFormat("bn-BD").format(Number(n||0));
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,7);

const defaultData={
  org:{name:"ফুলঢলুয়া মানবসেবা সংগঠন",address:"ফুলঢলুয়া, বরগুনা সদর",intro:"মানবতার সেবায়, সমাজের পাশে",phone:"",email:""},
  purpose:"অসহায় ও দরিদ্র মানুষের পাশে দাঁড়ানো, মানবিক সহায়তা পৌঁছে দেওয়া এবং এলাকার মানুষের মধ্যে সহযোগিতার বন্ধন তৈরি করা।",
  activityText:"খাদ্য সহায়তা, চিকিৎসা সহায়তা, শিক্ষা সহায়তা, জরুরি মানবিক সহায়তা এবং সামাজিক কল্যাণমূলক কার্যক্রম।",
  payments:{bkash:"01XXXXXXXXX",nagad:"01XXXXXXXXX",bank:"ব্যাংকের নাম",account:"",number:"",branch:""},
  members:[],activities:[],notices:[],donations:[],expenses:[],
  committee:Array.from({length:21},(_,i)=>({position:["সভাপতি","সহ-সভাপতি","সাধারণ সম্পাদক","সহ-সাধারণ সম্পাদক","সাংগঠনিক সম্পাদক","কোষাধ্যক্ষ","দপ্তর সম্পাদক","প্রচার সম্পাদক","সমাজকল্যাণ সম্পাদক","ক্রীড়া সম্পাদক","শিক্ষা সম্পাদক","সদস্য","সদস্য","সদস্য","সদস্য","সদস্য","সদস্য","সদস্য","সদস্য","সদস্য","সদস্য"][i],name:""}))
};

let data=structuredClone(defaultData);
let loggedUser=null;
let initialized=false;

function requireBackend(){
  if(!sb){
    alert("অনলাইন ডাটাবেস এখনো সংযুক্ত করা হয়নি। ZIP-এর supabase-config.js ফাইলে Supabase Project URL ও Publishable Key বসাতে হবে।");
    return false;
  }
  return true;
}

async function loadData(){
  if(!requireBackend()) return;
  const {data:row,error}=await sb.from("site_data").select("data").eq("id",1).maybeSingle();
  if(error){ console.error(error); alert("অনলাইন ডাটা লোড করা যায়নি। Supabase SQL/RLS সেটআপ পরীক্ষা করুন।"); return; }
  if(row?.data) data={...structuredClone(defaultData),...row.data};
  initialized=true;
  renderAll();
  renderAdmin();
}

async function save(){
  if(!requireBackend()) return false;
  if(!loggedUser){ alert("Admin লগইন করা নেই।"); return false; }
  const {error}=await sb.from("site_data").update({data,updated_at:new Date().toISOString()}).eq("id",1);
  if(error){ console.error(error); alert("ডাটা অনলাইনে সংরক্ষণ হয়নি। Admin অনুমতি/RLS পরীক্ষা করুন।"); return false; }
  renderAll();
  return true;
}

function page(id){
  document.querySelectorAll(".page").forEach(x=>x.classList.remove("active"));
  document.getElementById(id).classList.add("active");
  window.scrollTo({top:0,behavior:"smooth"});
  if(id==="admin") renderAdmin();
}
document.querySelectorAll("[data-page]").forEach(b=>b.onclick=()=>page(b.dataset.page));

function calc(){
  let donation=data.donations.reduce((s,x)=>s+Number(x.amount||0),0)+data.members.reduce((s,x)=>s+Number(x.annual||0),0);
  let expense=data.expenses.reduce((s,x)=>s+Number(x.amount||0),0);
  return {donation,expense,balance:donation-expense,paid:data.members.filter(x=>x.paid==="yes").length,unpaid:data.members.filter(x=>x.paid!=="yes").length}
}
function renderHome(){let c=calc();statDonation.textContent="৳ "+bn(c.donation);statExpense.textContent="৳ "+bn(c.expense);statPaid.textContent=bn(c.paid);statUnpaid.textContent=bn(c.unpaid);homeName.textContent=data.org.name;orgName.textContent=data.org.name;orgAddress.textContent=data.org.address}
function memberCard(m){return `<div class="card member">${m.photo?`<img class="avatar" src="${m.photo}" onerror="this.style.display='none'">`:`<div class="avatar"></div>`}<div><h3>${m.name}</h3><div>${m.position||"সদস্য"} ${m.id?`• ID: ${m.id}`:""}</div><small>${m.location||""}</small><br><small>এ বছরের অনুদান: <b>${m.paid==="yes"?"দিয়েছেন":"দেননি"}</b> • ৳${bn(m.annual)}</small></div></div>`}
function renderMembers(){memberCards.innerHTML=data.members.length?data.members.map(memberCard).join(""):`<div class="textcard">এখনও কোনো সদস্য যোগ করা হয়নি।</div>`}
function renderSearch(){searchBtn.onclick=()=>{let q=memberSearch.value.trim().toLowerCase();let ms=data.members.filter(m=>(m.name||"").toLowerCase().includes(q));searchResult.innerHTML=ms.length?ms.map(memberCard).join(""):`<div class="textcard">কোনো সদস্য পাওয়া যায়নি।</div>`}}
function renderCommittee(){committeeList.innerHTML=data.committee.map((x,i)=>`<div class="row"><div class="pos">${i+1}. ${x.position}</div><b>${x.name||"নাম যোগ করা হয়নি"}</b></div>`).join("")}
function renderDonations(){let paid=data.members.filter(x=>x.paid==="yes"), unpaid=data.members.filter(x=>x.paid!=="yes");paidList.innerHTML=paid.length?paid.map(memberCard).join(""):`<div class="textcard">কেউ অনুদান দেননি/রেকর্ড নেই।</div>`;unpaidList.innerHTML=unpaid.length?unpaid.map(memberCard).join(""):`<div class="textcard">সবাই অনুদান দিয়েছেন।</div>`}
function renderAccounts(){let c=calc();accDonation.textContent="৳"+bn(c.donation);accExpense.textContent="৳"+bn(c.expense);accCurrent.textContent="৳"+bn(c.balance);expenseList.innerHTML=data.expenses.length?data.expenses.map(x=>`<div class="card"><h3>${x.name}</h3><b>৳${bn(x.amount)}</b><div>${x.date||""}</div><p>${x.details||""}</p></div>`).join(""):`<div class="textcard">কোনো ব্যয়ের হিসাব নেই।</div>`}
function renderActivities(){activityList.innerHTML=data.activities.length?data.activities.map(x=>`<div class="card">${x.photo?`<img src="${x.photo}" style="width:100%;max-height:260px;object-fit:cover;border-radius:12px" onerror="this.style.display='none'">`:""}<h3>${x.name}</h3><small>${x.date||""}</small><p>${x.details||""}</p></div>`).join(""):`<div class="textcard">এখনও কোনো কার্যক্রম যোগ করা হয়নি।</div>`}
function renderNotices(){noticeList.innerHTML=data.notices.length?data.notices.slice().reverse().map(x=>`<div class="card"><h3>📢 ${x.title}</h3><small>${x.date||""}</small><p>${x.details||""}</p></div>`).join(""):`<div class="textcard">কোনো নোটিশ নেই।</div>`}
function renderInfo(){purposeText.textContent=data.purpose;activityText.textContent=data.activityText;contactAddress.textContent=data.org.address;contactPhone.textContent=data.org.phone||"তথ্য যোগ করা হয়নি";contactEmail.textContent=data.org.email||"তথ্য যোগ করা হয়নি";paymentInfo.innerHTML=`<div class="paycard"><strong>বিকাশ</strong><div class="paynumber">${data.payments.bkash}</div></div><div class="paycard"><strong>নগদ</strong><div class="paynumber">${data.payments.nagad}</div></div><div class="paycard"><strong>🏦 ব্যাংক অ্যাকাউন্ট</strong><p>${data.payments.bank}<br>${data.payments.account}<br>${data.payments.number}<br>${data.payments.branch}</p></div>`}

function renderAll(){renderHome();renderMembers();renderCommittee();renderDonations();renderAccounts();renderActivities();renderNotices();renderInfo();if(document.getElementById("adminBox")&&!document.getElementById("adminBox").hidden)renderAdmin()}

async function renderAdmin(){
  const {data:{session}}=sb?await sb.auth.getSession():{data:{session:null}};
  loggedUser=session?.user||null;
  loginBox.hidden=!!loggedUser; adminBox.hidden=!loggedUser;
  if(!loggedUser)return;
  let c=calc();aMembers.textContent=bn(data.members.length);aPaid.textContent=bn(c.paid);aUnpaid.textContent=bn(c.unpaid);aBalance.textContent="৳"+bn(c.balance);
  adminMembers.innerHTML=data.members.map(m=>`<div class="mini"><span>${m.name} • ${m.paid==="yes"?"দিয়েছেন":"বাকি"}</span><span><button onclick="editMember('${m._id}')">Edit</button> <button class="danger" onclick="delMember('${m._id}')">Delete</button></span></div>`).join("");
  adminActivities.innerHTML=data.activities.map(x=>`<div class="mini"><span>${x.name}</span><button class="danger" onclick="delActivity('${x._id}')">Delete</button></div>`).join("");
  adminNotices.innerHTML=data.notices.map(x=>`<div class="mini"><span>${x.title}</span><button class="danger" onclick="delNotice('${x._id}')">Delete</button></div>`).join("");
  adminDonations.innerHTML=data.donations.map(x=>`<div class="mini"><span>৳${bn(x.amount)} • ${x.date||""}</span><button class="danger" onclick="delDonation('${x._id}')">Delete</button></div>`).join("");
  adminExpenses.innerHTML=data.expenses.map(x=>`<div class="mini"><span>${x.name} • ৳${bn(x.amount)}</span><button class="danger" onclick="delExpense('${x._id}')">Delete</button></div>`).join("");
  purposeInput.value=data.purpose;activityInput.value=data.activityText;
  ["payBkash","payNagad","payBank","payAccount","payNumber","payBranch"].forEach((id,i)=>document.getElementById(id).value=Object.values(data.payments)[i]);
  ["oName","oAddress","oIntro","oPhone","oEmail"].forEach((id,i)=>document.getElementById(id).value=[data.org.name,data.org.address,data.org.intro,data.org.phone,data.org.email][i]);
  dMember.innerHTML=data.members.map(m=>`<option value="${m._id}">${m.name}</option>`).join("");
  committeeForm.innerHTML=data.committee.map((x,i)=>`<div class="formgrid"><input value="${x.position}" data-pos="${i}" placeholder="পদবী"><input value="${x.name}" data-com="${i}" placeholder="নাম"></div>`).join("")+`<button type="button" id="saveCommittee">কমিটি সংরক্ষণ</button>`;
  document.getElementById("saveCommittee").onclick=async()=>{data.committee.forEach((x,i)=>{x.position=document.querySelector(`[data-pos="${i}"]`).value;x.name=document.querySelector(`[data-com="${i}"]`).value});if(await save())alert("কমিটি অনলাইনে সংরক্ষণ হয়েছে");};
  const adminEmail=document.getElementById("adminEmailLabel"); if(adminEmail) adminEmail.textContent=loggedUser.email||"";
}

window.editMember=id=>{let m=data.members.find(x=>x._id===id);if(!m)return;memberId.value=id;mName.value=m.name;mPhoto.value=m.photo||"";mId.value=m.id||"";mPhone.value=m.phone||"";mPosition.value=m.position||"";mLocation.value=m.location||"";mPaid.value=m.paid;mAnnual.value=m.annual||0;mDate.value=m.date||"";mMethod.value=m.method||"bKash";mTotal.value=m.total||0;window.scrollTo({top:document.querySelector(".admin-section").offsetTop,behavior:"smooth"})};
window.delMember=async id=>{if(confirm("সদস্যটি মুছে ফেলবেন?")){data.members=data.members.filter(x=>x._id!==id);data.donations=data.donations.filter(x=>x.memberId!==id);await save()}};
window.delActivity=async id=>{data.activities=data.activities.filter(x=>x._id!==id);await save()};
window.delNotice=async id=>{data.notices=data.notices.filter(x=>x._id!==id);await save()};
window.delDonation=async id=>{data.donations=data.donations.filter(x=>x._id!==id);await save()};
window.delExpense=async id=>{data.expenses=data.expenses.filter(x=>x._id!==id);await save()};

loginBtn.onclick=async()=>{
  if(!requireBackend())return;
  const {error}=await sb.auth.signInWithPassword({email:loginUser.value.trim(),password:loginPass.value});
  if(error){alert("ইমেইল বা পাসওয়ার্ড ভুল, অথবা এই Admin এখনো অনুমোদিত নয়।");return}
  await loadData(); await renderAdmin();
};
logoutBtn.onclick=async()=>{if(sb)await sb.auth.signOut();loggedUser=null;renderAdmin()};

memberForm.onsubmit=async e=>{e.preventDefault();let id=memberId.value||uid();let old=data.members.find(x=>x._id===id)||{};let m={...old,_id:id,name:mName.value,photo:mPhoto.value,id:mId.value,phone:mPhone.value,position:mPosition.value,location:mLocation.value,paid:mPaid.value,annual:Number(mAnnual.value||0),date:mDate.value,method:mMethod.value,total:Number(mTotal.value||0)};let i=data.members.findIndex(x=>x._id===id);i>=0?data.members[i]=m:data.members.push(m);if(await save()){memberForm.reset();memberId.value="";alert("সদস্য অনলাইনে সংরক্ষণ হয়েছে")}};

clearMember.onclick=()=>memberForm.reset();
activityForm.onsubmit=async e=>{e.preventDefault();data.activities.push({_id:uid(),name:actName.value,date:actDate.value,details:actDetails.value,photo:actPhoto.value});if(await save()){activityForm.reset();alert("কার্যক্রম অনলাইনে যোগ হয়েছে")}};
noticeForm.onsubmit=async e=>{e.preventDefault();data.notices.push({_id:uid(),title:noticeTitle.value,date:noticeDate.value,details:noticeDetails.value});if(await save()){noticeForm.reset();alert("নোটিশ অনলাইনে প্রকাশ হয়েছে")}};
savePurpose.onclick=async()=>{data.purpose=purposeInput.value;data.activityText=activityInput.value;if(await save())alert("সংরক্ষণ হয়েছে")};
paymentForm.onsubmit=async e=>{e.preventDefault();data.payments={bkash:payBkash.value,nagad:payNagad.value,bank:payBank.value,account:payAccount.value,number:payNumber.value,branch:payBranch.value};if(await save())alert("অনুদান গ্রহণের তথ্য সংরক্ষণ হয়েছে")};
orgForm.onsubmit=async e=>{e.preventDefault();data.org={name:oName.value,address:oAddress.value,intro:oIntro.value,phone:oPhone.value,email:oEmail.value};if(await save())alert("পরিচিতি সংরক্ষণ হয়েছে")};
donationForm.onsubmit=async e=>{e.preventDefault();data.donations.push({_id:uid(),memberId:dMember.value,amount:Number(dAmount.value||0),date:dDate.value,method:dMethod.value});if(await save())alert("অনুদান যোগ হয়েছে")};
expenseForm.onsubmit=async e=>{e.preventDefault();data.expenses.push({_id:uid(),name:eName.value,amount:Number(eAmount.value||0),date:eDate.value,details:eDetails.value});if(await save())alert("ব্যয়ের হিসাব যোগ হয়েছে")};

renderSearch();
renderAll();

(async()=>{
  if(!sb){renderAdmin();return}
  const {data:{session}}=await sb.auth.getSession();
  loggedUser=session?.user||null;
  await loadData();
  await renderAdmin();
  sb.channel("fms-site-data").on("postgres_changes",{event:"UPDATE",schema:"public",table:"site_data",filter:"id=eq.1"},payload=>{
    if(payload.new?.data){data={...structuredClone(defaultData),...payload.new.data};renderAll();}
  }).subscribe();
})();

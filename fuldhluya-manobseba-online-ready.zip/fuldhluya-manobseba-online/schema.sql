-- ফুলঢলুয়া মানবসেবা সংগঠন — Supabase database setup
-- এই SQL Supabase Dashboard > SQL Editor-এ একবার চালান।

create table if not exists public.site_data (
  id bigint primary key check (id = 1),
  data jsonb not null,
  updated_at timestamptz not null default now()
);

insert into public.site_data (id, data)
values (1, '{
  "org":{"name":"ফুলঢলুয়া মানবসেবা সংগঠন","address":"ফুলঢলুয়া, বরগুনা সদর","intro":"মানবতার সেবায়, সমাজের পাশে","phone":"","email":""},
  "purpose":"অসহায় ও দরিদ্র মানুষের পাশে দাঁড়ানো, মানবিক সহায়তা পৌঁছে দেওয়া এবং এলাকার মানুষের মধ্যে সহযোগিতার বন্ধন তৈরি করা।",
  "activityText":"খাদ্য সহায়তা, চিকিৎসা সহায়তা, শিক্ষা সহায়তা, জরুরি মানবিক সহায়তা এবং সামাজিক কল্যাণমূলক কার্যক্রম।",
  "payments":{"bkash":"01XXXXXXXXX","nagad":"01XXXXXXXXX","bank":"ব্যাংকের নাম","account":"","number":"","branch":""},
  "members":[],"activities":[],"notices":[],"donations":[],"expenses":[],
  "committee":[
    {"position":"সভাপতি","name":""},{"position":"সহ-সভাপতি","name":""},{"position":"সাধারণ সম্পাদক","name":""},{"position":"সহ-সাধারণ সম্পাদক","name":""},{"position":"সাংগঠনিক সম্পাদক","name":""},{"position":"কোষাধ্যক্ষ","name":""},{"position":"দপ্তর সম্পাদক","name":""},{"position":"প্রচার সম্পাদক","name":""},{"position":"সমাজকল্যাণ সম্পাদক","name":""},{"position":"ক্রীড়া সম্পাদক","name":""},{"position":"শিক্ষা সম্পাদক","name":""},{"position":"সদস্য","name":""},{"position":"সদস্য","name":""},{"position":"সদস্য","name":""},{"position":"সদস্য","name":""},{"position":"সদস্য","name":""},{"position":"সদস্য","name":""},{"position":"সদস্য","name":""},{"position":"সদস্য","name":""},{"position":"সদস্য","name":""},{"position":"সদস্য","name":""}
  ]
}'::jsonb)
on conflict (id) do nothing;

create table if not exists public.admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.site_data enable row level security;
alter table public.admins enable row level security;

drop policy if exists "public can read site data" on public.site_data;
create policy "public can read site data"
on public.site_data for select to anon, authenticated using (true);

drop policy if exists "admins can update site data" on public.site_data;
create policy "admins can update site data"
on public.site_data for update to authenticated
using (exists (select 1 from public.admins a where a.user_id = auth.uid()))
with check (exists (select 1 from public.admins a where a.user_id = auth.uid()));

drop policy if exists "admin can read own admin row" on public.admins;
create policy "admin can read own admin row"
on public.admins for select to authenticated
using (user_id = auth.uid());

grant select on public.site_data to anon, authenticated;
grant update on public.site_data to authenticated;
grant select on public.admins to authenticated;

-- Realtime: enable changes for site_data so visitors can see Admin updates without refreshing.
do $$
begin
  alter publication supabase_realtime add table public.site_data;
exception when duplicate_object then null;
end $$;

-- নিরাপত্তা:
-- 1) Browser-এ শুধু Publishable/anon key ব্যবহার করবেন।
-- 2) service_role/secret key কখনো supabase-config.js-এ রাখবেন না।
-- 3) নিচের INSERT-টি Admin Auth user তৈরির পর চালাতে হবে:
-- insert into public.admins(user_id) values ('AUTH_USER_UUID_HERE');

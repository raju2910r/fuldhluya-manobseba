// Supabase connection settings for ফুলঢলুয়া মানবসেবা সংগঠন
// Publishable key is safe for browser use when RLS policies are correctly configured.
// NEVER put a secret/service_role key in this file.
window.FMS_SUPABASE_URL = "https://ohfzchxibxchknivlgrr.supabase.co";
window.FMS_SUPABASE_PUBLISHABLE_KEY = "sb_publishable_vCr4wttAg0pzqsyrr6FXDA_5pwxX2ox";
